﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace MySpace
{
    public class SMFReader : IDisposable
    {
        public uint TimeDivision;
        public class MidiEvent
        {
            public uint delta;
            public byte state;
            public byte arg0;
            public byte arg1;
            public byte[] opt;
        }
        public List<List<MidiEvent>> Tracks
        {
            get;
            private set;
        }

        private bool disposed = false;
        private FileStream fileStream;
        private BinaryReader binaryReader;
        private uint fmtType;
        private uint numOfTracks;
        private uint chunkPos;
        private uint chunkLen;
        private uint readValue(int len)
        {
            if (chunkPos + len > chunkLen)
            {
                throw new System.Exception(fileStream.Position.ToString() + ": Overrun!");
            }
            chunkPos += (uint)len;
            byte[] d = binaryReader.ReadBytes(len);
            uint v = 0;
            for (int i = 0; i < len; i++)
            {
                v = (v << 8) | d[i];
            }
            return v;
        }
        private byte[] readBytes(int n)
        {
            if (chunkPos + n > chunkLen)
            {
                throw new System.Exception(fileStream.Position.ToString() + ": Overrun!");
            }
            chunkPos += (uint)n;
            return binaryReader.ReadBytes(n);
        }
        private byte readByte()
        {
            if (chunkPos + 1 > chunkLen)
            {
                throw new System.Exception(fileStream.Position.ToString() + ": Overrun!");
            }
            chunkPos += 1U;
            return binaryReader.ReadByte();
        }
        private uint readDelta()
        {
            uint v = 0;
            byte d;
            int cnt = 0;
            do
            {
                if (cnt++ >= 4)
                {
                    throw new System.Exception(fileStream.Position.ToString() + ": Illegal delta.");
                }
                d = readByte();
                v = (v << 7) | (d & 0x7fU);
            } while (d >= 128);
            return v;
        }
        private uint readDelta(byte d0)
        {
            uint v = d0 & 0x7fU;
            if (d0 < 128)
            {
                return v;
            }
            byte d;
            int cnt = 1;
            do
            {
                if (cnt++ >= 4)
                {
                    throw new System.Exception(fileStream.Position.ToString() + ": Illegal delta.");
                }
                d = readByte();
                v = (v << 7) | (d & 0x7fU);
            } while (d >= 128);
            return v;
        }
        private void parseHeader()
        {
            byte[] tag = binaryReader.ReadBytes(4);
            if (!tag.SequenceEqual(new byte[4] { (byte)'M', (byte)'T', (byte)'h', (byte)'d' }))
            {
                throw new System.Exception(fileStream.Position.ToString() + ": not SMF file.");
            }
            chunkLen = 4;
            chunkPos = 0;
            chunkLen = readValue(4);
            chunkPos = 0;
            if (chunkLen != 6)
            {
                throw new System.Exception(fileStream.Position.ToString() + ": headerLength=" + chunkLen + " : Unknown header.");
            }
            fmtType = readValue(2);
            if ((fmtType != 0) && (fmtType != 1))
            {
                throw new System.Exception(fileStream.Position.ToString() + ": fmtType=" + fmtType + " : Unknown type.");
            }
            numOfTracks = readValue(2);
            if (numOfTracks == 0)
            {
                throw new System.Exception(fileStream.Position.ToString() + ": Empty");
            }
            if ((fmtType == 0) && (numOfTracks != 1))
            {
                throw new System.Exception(fileStream.Position.ToString() + ": fmtType=" + fmtType + " numOfTracks=" + numOfTracks + " : Illegal data.");
            }
            TimeDivision = readValue(2);
            if (TimeDivision == 0)
            {
                throw new System.Exception(fileStream.Position.ToString() + ": timeDivision=" + TimeDivision + " : Illegal data.");
            }
            if (TimeDivision > 32768)
            {
                throw new System.Exception(fileStream.Position.ToString() + ": timeDivision=" + TimeDivision + " : Not supported.");
            }
        }
        private void parseTrack()
        {
            byte[] tag = binaryReader.ReadBytes(4);
            if (!tag.SequenceEqual(new byte[4] { (byte)'M', (byte)'T', (byte)'r', (byte)'k' }))
            {
                throw new System.Exception(fileStream.Position.ToString() + ": tag=" + tag + "Unknown chunk.");
            }
            chunkLen = 4;
            chunkPos = 0;
            chunkLen = readValue(4);
            chunkPos = 0;

            List<MidiEvent> track = new List<MidiEvent>();
            Tracks.Add(track);
            while (chunkPos < chunkLen)
            {
                byte state = 0;
                uint delta = readDelta();
                byte d0 = readByte();
                if (d0 >= 128)
                {
                    state = d0;
                    d0 = readByte();
                }
                MidiEvent ev = new MidiEvent();
                ev.state = state;
                ev.delta = delta;
                switch (state & 0xf0U)
                {
                    case 0x80U: // note off: note, velocity
                    case 0x90U: // note on: note, velocity
                    case 0xa0U: // polyphonic kye pressure: note, pressure
                    case 0xb0U: // contorl change: num, val
                    case 0xe0U: // pitch bend: msb, lsb
                        ev.arg0 = d0;
                        ev.arg1 = readByte();
                        break;
                    case 0xc0U: // program change: num
                    case 0xd0U: // channel pressure: pressure
                        ev.arg0 = d0;
                        break;
                    case 0xf0U: // system message: 
                        if ((state == 0xf0U) || (state == 0xf7U))
                        {
                            uint l = readDelta(d0);
                            ev.opt = readBytes((int)l);
                        }
                        else if (state == 0xffU)
                        {
                            uint l = readDelta();
                            ev.arg0 = d0;
                            ev.opt = readBytes((int)l);
                        }
                        else
                        {
                            throw new System.Exception(fileStream.Position.ToString() + ": state=" + state + "Unknown system message.");
                        }
                        break;
                    default:
                        throw new System.Exception(fileStream.Position.ToString() + ": state=" + state + "Unknown MIDI state.");
                }
                track.Add(ev);
            }
        }
        public SMFReader(string Path)
        {
            fileStream = new FileStream(Path, FileMode.Open, FileAccess.Read);
            binaryReader = new BinaryReader(fileStream);
            Tracks = new List<List<MidiEvent>>();
            parseHeader();
            for (int i = 0; i < numOfTracks; i++)
            {
                parseTrack();
            }
        }
        ~SMFReader()
        {
            Dispose(false);
        }
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        protected virtual void Dispose(bool Disposing)
        {
            if (!this.disposed)
            {
                if (Disposing)
                {
                    this.binaryReader.Close();
                    this.binaryReader = null;
                    this.fileStream.Close();
                    this.fileStream = null;
                }
                this.disposed = true;
            }
        }
        public void Close()
        {
            Dispose();
        }
    }
}
